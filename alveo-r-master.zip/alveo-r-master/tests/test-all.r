library(testthat)
test_check("alveo")